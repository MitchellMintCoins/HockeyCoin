To get an updated client, go to http://coingen.io
