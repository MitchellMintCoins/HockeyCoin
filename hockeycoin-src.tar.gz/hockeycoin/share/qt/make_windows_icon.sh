#!/bin/bash
# create multiresolution windows icon
ICON_SRC=../../src/qt/res/icons/hockeycoin.png
ICON_DST=../../src/qt/res/icons/hockeycoin.ico
convert ${ICON_SRC} -resize 16x16 hockeycoin-16.png
convert ${ICON_SRC} -resize 32x32 hockeycoin-32.png
convert ${ICON_SRC} -resize 48x48 hockeycoin-48.png
convert hockeycoin-16.png hockeycoin-32.png hockeycoin-48.png ${ICON_DST}

